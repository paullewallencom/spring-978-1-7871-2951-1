==================

## Section 1 - Spring Security Setup

- **Video 1** - `Spring Security Setup and Form Based Authentication`
- **Video 2** - `Authentication - Login and Logout`
- **Video 3** - `Authorization by URL`
- **Video 4** - `Authorization Expressions`
- **Video 5** - `In Page Authorization`


## Section References
- 
